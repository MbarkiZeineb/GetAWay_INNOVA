<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* promostion/_form.html.twig */
class __TwigTemplate_ca957af7bce6dfff8786bbe3c866cd0c3e96a7d1f62cbcfede4fb96b96546537 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base_front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "promostion/_form.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "promostion/_form.html.twig"));

        $this->parent = $this->loadTemplate("base_front.html.twig", "promostion/_form.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    ";
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 4, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        echo "
    <div class=\"card-body\">

        <form>

            <div class=\"form-group\">
                <label class=\"form-label\" for=\"exampleInputEmail2\">Pourcentage a reduire </label>
                ";
        // line 11
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 11, $this->source); })()), "pourcentage", [], "any", false, false, false, 11), 'widget', ["attr" => ["class" => "form-control form-control-user"]]);
        echo "
                <div>
                    <p class=\"card-description\"> <code> ";
        // line 13
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 13, $this->source); })()), "pourcentage", [], "any", false, false, false, 13), 'errors');
        echo "</code></p>
                </div>
            </div>
            <div class=\"form-group\">
                <label class=\"form-label\" for=\"exampleInputEmail2\">Debut de promotion </label>
                ";
        // line 18
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 18, $this->source); })()), "dateStart", [], "any", false, false, false, 18), 'widget', ["attr" => ["class" => "form-control form-control-user"]]);
        echo "
                <div>
                    <p class=\"card-description\"> <code> ";
        // line 20
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 20, $this->source); })()), "dateStart", [], "any", false, false, false, 20), 'errors');
        echo "</code></p>
                </div>
            </div>
            <div class=\"form-group\">
                <label class=\"form-label\" for=\"exampleInputEmail2\">Fin de promotion</label>
                ";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 25, $this->source); })()), "dateEnd", [], "any", false, false, false, 25), 'widget', ["attr" => ["class" => "form-control form-control-user"]]);
        echo "
                <div>
                    <p class=\"card-description\"> <code> ";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 27, $this->source); })()), "dateEnd", [], "any", false, false, false, 27), 'errors');
        echo "</code></p>
                </div>
            </div>
            <div class=\"form-group\">
                <label class=\"form-label\" for=\"exampleInputEmail2\">Le hebergement a Modifer</label>
                ";
        // line 32
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 32, $this->source); })()), "refHebergement", [], "any", false, false, false, 32), 'widget', ["attr" => ["class" => "form-control form-control-user"]]);
        echo "
                <div>
                    <p class=\"card-description\"> <code> ";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 34, $this->source); })()), "refHebergement", [], "any", false, false, false, 34), 'errors');
        echo "</code></p>
                </div>
            </div>
            <div class=\"form-group mb-0\">
                <div class=\"checkbox checkbox-secondary\">
                    ";
        // line 39
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 39, $this->source); })()), 'widget');
        echo "
                    <button type=\"SubmitType\" class=\"btn btn-primary \">";
        // line 40
        echo twig_escape_filter($this->env, ((array_key_exists("button_label", $context)) ? (_twig_default_filter((isset($context["button_label"]) || array_key_exists("button_label", $context) ? $context["button_label"] : (function () { throw new RuntimeError('Variable "button_label" does not exist.', 40, $this->source); })()), "Save")) : ("Save")), "html", null, true);
        echo "</button>
                </div>
            </div>

        </form>
    </div>
    ";
        // line 46
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 46, $this->source); })()), 'form_end');
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "promostion/_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 46,  135 => 40,  131 => 39,  123 => 34,  118 => 32,  110 => 27,  105 => 25,  97 => 20,  92 => 18,  84 => 13,  79 => 11,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base_front.html.twig' %}

{% block content %}
    {{ form_start(form, {'attr': {'novalidate':'novalidate'}} ) }}
    <div class=\"card-body\">

        <form>

            <div class=\"form-group\">
                <label class=\"form-label\" for=\"exampleInputEmail2\">Pourcentage a reduire </label>
                {{ form_widget(form.pourcentage , {'attr': {'class': 'form-control form-control-user' }} ) }}
                <div>
                    <p class=\"card-description\"> <code> {{ form_errors(form.pourcentage) }}</code></p>
                </div>
            </div>
            <div class=\"form-group\">
                <label class=\"form-label\" for=\"exampleInputEmail2\">Debut de promotion </label>
                {{ form_widget(form.dateStart , {'attr': {'class': 'form-control form-control-user' }} ) }}
                <div>
                    <p class=\"card-description\"> <code> {{ form_errors(form.dateStart) }}</code></p>
                </div>
            </div>
            <div class=\"form-group\">
                <label class=\"form-label\" for=\"exampleInputEmail2\">Fin de promotion</label>
                {{ form_widget(form.dateEnd , {'attr': {'class': 'form-control form-control-user' }} ) }}
                <div>
                    <p class=\"card-description\"> <code> {{ form_errors(form.dateEnd) }}</code></p>
                </div>
            </div>
            <div class=\"form-group\">
                <label class=\"form-label\" for=\"exampleInputEmail2\">Le hebergement a Modifer</label>
                {{ form_widget(form.refHebergement , {'attr': {'class': 'form-control form-control-user' }} ) }}
                <div>
                    <p class=\"card-description\"> <code> {{ form_errors(form.refHebergement) }}</code></p>
                </div>
            </div>
            <div class=\"form-group mb-0\">
                <div class=\"checkbox checkbox-secondary\">
                    {{ form_widget(form) }}
                    <button type=\"SubmitType\" class=\"btn btn-primary \">{{ button_label|default('Save') }}</button>
                </div>
            </div>

        </form>
    </div>
    {{ form_end(form) }}
{% endblock %}", "promostion/_form.html.twig", "C:\\Users\\Rayen's PC\\gestionhebergementall\\templates\\promostion\\_form.html.twig");
    }
}
