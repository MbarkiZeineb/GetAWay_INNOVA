<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* promostion/show.html.twig */
class __TwigTemplate_355013b4b90b389dbfb1e54b7b5ad1601764116ec2874bab772aa764b3b5f9e9 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base_front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "promostion/show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "promostion/show.html.twig"));

        $this->parent = $this->loadTemplate("base_front.html.twig", "promostion/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "    <br>
    <br>
    <br>
    <br>
    <center><h1> Promotion Selected</h1></center>

    <table class=\"table\">
        <tbody>
            <tr>
                <th>IdRef</th>
                <td>";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["promostion"]) || array_key_exists("promostion", $context) ? $context["promostion"] : (function () { throw new RuntimeError('Variable "promostion" does not exist.', 15, $this->source); })()), "idRef", [], "any", false, false, false, 15), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Pourcentage</th>
                <td>";
        // line 19
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["promostion"]) || array_key_exists("promostion", $context) ? $context["promostion"] : (function () { throw new RuntimeError('Variable "promostion" does not exist.', 19, $this->source); })()), "pourcentage", [], "any", false, false, false, 19), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>DateStart</th>
                <td>";
        // line 23
        ((twig_get_attribute($this->env, $this->source, (isset($context["promostion"]) || array_key_exists("promostion", $context) ? $context["promostion"] : (function () { throw new RuntimeError('Variable "promostion" does not exist.', 23, $this->source); })()), "dateStart", [], "any", false, false, false, 23)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["promostion"]) || array_key_exists("promostion", $context) ? $context["promostion"] : (function () { throw new RuntimeError('Variable "promostion" does not exist.', 23, $this->source); })()), "dateStart", [], "any", false, false, false, 23), "Y-m-d"), "html", null, true))) : (print ("")));
        echo "</td>
            </tr>
            <tr>
                <th>DateEnd</th>
                <td>";
        // line 27
        ((twig_get_attribute($this->env, $this->source, (isset($context["promostion"]) || array_key_exists("promostion", $context) ? $context["promostion"] : (function () { throw new RuntimeError('Variable "promostion" does not exist.', 27, $this->source); })()), "dateEnd", [], "any", false, false, false, 27)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["promostion"]) || array_key_exists("promostion", $context) ? $context["promostion"] : (function () { throw new RuntimeError('Variable "promostion" does not exist.', 27, $this->source); })()), "dateEnd", [], "any", false, false, false, 27), "Y-m-d"), "html", null, true))) : (print ("")));
        echo "</td>
            </tr>
            <tr>
                <th>Hebergement avait une promotion</th>
                <td>";
        // line 31
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["promostion"]) || array_key_exists("promostion", $context) ? $context["promostion"] : (function () { throw new RuntimeError('Variable "promostion" does not exist.', 31, $this->source); })()), "refHebergement", [], "any", false, false, false, 31), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <a href=\"";
        // line 36
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_promostion_index");
        echo "\">back to list</a>

    <a href=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_promostion_edit", ["idRef" => twig_get_attribute($this->env, $this->source, (isset($context["promostion"]) || array_key_exists("promostion", $context) ? $context["promostion"] : (function () { throw new RuntimeError('Variable "promostion" does not exist.', 38, $this->source); })()), "idRef", [], "any", false, false, false, 38)]), "html", null, true);
        echo "\">edit</a>

    ";
        // line 40
        echo twig_include($this->env, $context, "promostion/_delete_form.html.twig");
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "promostion/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 40,  121 => 38,  116 => 36,  108 => 31,  101 => 27,  94 => 23,  87 => 19,  80 => 15,  68 => 5,  58 => 4,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base_front.html.twig' %}


{% block content %}
    <br>
    <br>
    <br>
    <br>
    <center><h1> Promotion Selected</h1></center>

    <table class=\"table\">
        <tbody>
            <tr>
                <th>IdRef</th>
                <td>{{ promostion.idRef }}</td>
            </tr>
            <tr>
                <th>Pourcentage</th>
                <td>{{ promostion.pourcentage }}</td>
            </tr>
            <tr>
                <th>DateStart</th>
                <td>{{ promostion.dateStart ? promostion.dateStart|date('Y-m-d') : '' }}</td>
            </tr>
            <tr>
                <th>DateEnd</th>
                <td>{{ promostion.dateEnd ? promostion.dateEnd|date('Y-m-d') : '' }}</td>
            </tr>
            <tr>
                <th>Hebergement avait une promotion</th>
                <td>{{ promostion.refHebergement }}</td>
            </tr>
        </tbody>
    </table>

    <a href=\"{{ path('app_promostion_index') }}\">back to list</a>

    <a href=\"{{ path('app_promostion_edit', {'idRef': promostion.idRef}) }}\">edit</a>

    {{ include('promostion/_delete_form.html.twig') }}
{% endblock %}
", "promostion/show.html.twig", "C:\\Users\\Rayen's PC\\gestionhebergementall\\templates\\promostion\\show.html.twig");
    }
}
