<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* hebergement/hebergementB.html.twig */
class __TwigTemplate_0dd6574d5c787e5dad7ae956d779e177df91246ee2667ab2b1b48bf309f98147 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base_back.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "hebergement/hebergementB.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "hebergement/hebergementB.html.twig"));

        $this->parent = $this->loadTemplate("base_back.html.twig", "hebergement/hebergementB.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <br>
    <br>
    <br>
    <br>


    <center><h1>Gestion de Hebergement</h1></center>
    <table class=\"table\">
        <div class=\"pull-right\">
            <a href=\" ";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sortedVol", ["id" => 1]);
        echo "\" class=\"btn btn-info\" > trier par prix</a>
        </div>
        <thead>
        <tr>
            <th>Referance</th>
            <th>Paye</th>
            <th>Adress</th>
            <th>Prix</th>
            <th>Category</th>
            <th>Description</th>
            <th>Photo</th>
            <th>DateStart</th>
            <th>DateEnd</th>
            <th>Contact</th>
            <th>NbrDetoile</th>
            <th>NbrSuite</th>
            <th>NbrParking</th>
            <th>ModelCaravane</th>


        </tr>
        </thead>
        <tbody>

        <p style=\"margin-left: 950px\"><label for=\"myInput\"></label><input id=\"myInput\" type=\"text\" placeholder=\"Search..\">

        <tbody  id=\"myTable\">
        <button  class=\"btn btn-info mr-2\" onclick=\"window.print()\" ><i class=\"fa fa-print\" aria-hidden=\"true\"></i></i>  Imprimer</button>
        ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["hebergements"]) || array_key_exists("hebergements", $context) ? $context["hebergements"] : (function () { throw new RuntimeError('Variable "hebergements" does not exist.', 40, $this->source); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["hebergement"]) {
            // line 41
            echo "            <tr>
                <td>";
            // line 42
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "referance", [], "any", false, false, false, 42), "html", null, true);
            echo "</td>
                <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "paye", [], "any", false, false, false, 43), "html", null, true);
            echo "</td>
                <td>";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "adress", [], "any", false, false, false, 44), "html", null, true);
            echo "</td>
                <td>";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "prix", [], "any", false, false, false, 45), "html", null, true);
            echo "</td>
                <td>";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "idcateg", [], "any", false, false, false, 46), "html", null, true);
            echo "</td>
                <td>";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "description", [], "any", false, false, false, 47), "html", null, true);
            echo "</td>
                <td><img src=\"";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "photo", [], "any", false, false, false, 48), "html", null, true);
            echo "\" style=\"height:100px;width:100px\"></td>
                <td>";
            // line 49
            ((twig_get_attribute($this->env, $this->source, $context["hebergement"], "dateStart", [], "any", false, false, false, 49)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "dateStart", [], "any", false, false, false, 49), "Y-m-d"), "html", null, true))) : (print ("")));
            echo "</td>
                <td>";
            // line 50
            ((twig_get_attribute($this->env, $this->source, $context["hebergement"], "dateEnd", [], "any", false, false, false, 50)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "dateEnd", [], "any", false, false, false, 50), "Y-m-d"), "html", null, true))) : (print ("")));
            echo "</td>
                <td>";
            // line 51
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "contact", [], "any", false, false, false, 51), "html", null, true);
            echo "</td>
                <td>";
            // line 52
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "nbrDetoile", [], "any", false, false, false, 52), "html", null, true);
            echo "</td>
                <td>";
            // line 53
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "nbrSuite", [], "any", false, false, false, 53), "html", null, true);
            echo "</td>
                <td>";
            // line 54
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "nbrParking", [], "any", false, false, false, 54), "html", null, true);
            echo "</td>
                <td>";
            // line 55
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hebergement"], "modelCaravane", [], "any", false, false, false, 55), "html", null, true);
            echo "</td>

                <td>


                </td>
            </tr>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 63
            echo "            <tr>
                <td colspan=\"14\">no records found</td>
            </tr>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hebergement'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 68
        echo "

        </tbody>
    </table>
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>
    <script>
        \$(document).ready(function(){
            \$(\"#myInput\").on(\"keyup\", function() {
                var value = \$(this).val().toLowerCase();
                \$(\"#myTable tr\").filter(function() {
                    \$(this).toggle(\$(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "hebergement/hebergementB.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  193 => 68,  183 => 63,  170 => 55,  166 => 54,  162 => 53,  158 => 52,  154 => 51,  150 => 50,  146 => 49,  142 => 48,  138 => 47,  134 => 46,  130 => 45,  126 => 44,  122 => 43,  118 => 42,  115 => 41,  110 => 40,  79 => 12,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base_back.html.twig' %}
{% block content %}
    <br>
    <br>
    <br>
    <br>


    <center><h1>Gestion de Hebergement</h1></center>
    <table class=\"table\">
        <div class=\"pull-right\">
            <a href=\" {{ path('sortedVol',{'id':1} ) }}\" class=\"btn btn-info\" > trier par prix</a>
        </div>
        <thead>
        <tr>
            <th>Referance</th>
            <th>Paye</th>
            <th>Adress</th>
            <th>Prix</th>
            <th>Category</th>
            <th>Description</th>
            <th>Photo</th>
            <th>DateStart</th>
            <th>DateEnd</th>
            <th>Contact</th>
            <th>NbrDetoile</th>
            <th>NbrSuite</th>
            <th>NbrParking</th>
            <th>ModelCaravane</th>


        </tr>
        </thead>
        <tbody>

        <p style=\"margin-left: 950px\"><label for=\"myInput\"></label><input id=\"myInput\" type=\"text\" placeholder=\"Search..\">

        <tbody  id=\"myTable\">
        <button  class=\"btn btn-info mr-2\" onclick=\"window.print()\" ><i class=\"fa fa-print\" aria-hidden=\"true\"></i></i>  Imprimer</button>
        {% for hebergement in hebergements %}
            <tr>
                <td>{{ hebergement.referance }}</td>
                <td>{{ hebergement.paye }}</td>
                <td>{{ hebergement.adress }}</td>
                <td>{{ hebergement.prix }}</td>
                <td>{{ hebergement.idcateg }}</td>
                <td>{{ hebergement.description }}</td>
                <td><img src=\"{{ hebergement.photo }}\" style=\"height:100px;width:100px\"></td>
                <td>{{ hebergement.dateStart ? hebergement.dateStart|date('Y-m-d') : '' }}</td>
                <td>{{ hebergement.dateEnd ? hebergement.dateEnd|date('Y-m-d') : '' }}</td>
                <td>{{ hebergement.contact }}</td>
                <td>{{ hebergement.nbrDetoile }}</td>
                <td>{{ hebergement.nbrSuite }}</td>
                <td>{{ hebergement.nbrParking }}</td>
                <td>{{ hebergement.modelCaravane }}</td>

                <td>


                </td>
            </tr>
        {% else %}
            <tr>
                <td colspan=\"14\">no records found</td>
            </tr>

        {% endfor %}


        </tbody>
    </table>
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>
    <script>
        \$(document).ready(function(){
            \$(\"#myInput\").on(\"keyup\", function() {
                var value = \$(this).val().toLowerCase();
                \$(\"#myTable tr\").filter(function() {
                    \$(this).toggle(\$(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

{% endblock %}
", "hebergement/hebergementB.html.twig", "C:\\Users\\Rayen's PC\\gestionhebergementall\\templates\\hebergement\\hebergementB.html.twig");
    }
}
