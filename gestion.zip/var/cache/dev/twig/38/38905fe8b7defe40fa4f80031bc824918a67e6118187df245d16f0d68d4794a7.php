<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base_front.html.twig */
class __TwigTemplate_67e6fe8a203e7bdf1ac91bed753484b88b14669f5f2fa367df719ed5e207531f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'search' => [$this, 'block_search'],
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base_front.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base_front.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
";
        // line 3
        $this->displayBlock('search', $context, $blocks);
        // line 5
        echo "    <head>
    <meta charset=\"UTF-8\">
    <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 10
        echo "
    ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 69
        echo "
";
        // line 70
        $this->displayBlock('javascripts', $context, $blocks);
        // line 96
        echo "</head>
<body class=\"default-page\">
<div class=\"preloader\" id=\"pageLoad\">
    <div class=\"holder\">
        <div class=\"coffee_cup\"></div>
    </div>
</div>
<div id=\"wrapper\">
    <div class=\"page-wrapper\">
        ";
        // line 105
        $this->displayBlock('header', $context, $blocks);
        // line 404
        echo "


        ";
        // line 407
        $this->displayBlock('content', $context, $blocks);
        // line 413
        echo "    </div>
    ";
        // line 414
        $this->displayBlock('footer', $context, $blocks);
        // line 581
        echo "</div>
<!-- scroll to top -->
<div class=\"scroll-holder text-center\">
    <a href=\"javascript:\" id=\"scroll-to-top\"
    ><i class=\"icon-arrow-down\"></i
        ></a>
</div>

</body>
</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_search($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "search"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "search"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " GetAWay ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 12
        echo "    ";
        // line 13
        echo "    <meta charset=\"utf-8\" />
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title>Entrada</title>
    <!-- favion -->
    <link
            rel=\"icon\"
            type=\"image/png\"
            sizes=\"16x16\"
            href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/img/favicon-16x16.png"), "html", null, true);
        echo "\"
    />
    <!-- link to font awesome -->
    <link
            media=\"all\"
            rel=\"stylesheet\"
            href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/font-awesome/css/font-awesome.css"), "html", null, true);
        echo "\"
    />
    <!-- link to material icon font -->
    <link
            media=\"all\"
            rel=\"stylesheet\"
            href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/material-design-icons/material-icons.css"), "html", null, true);
        echo "\"
    />

    <link
            rel=\"stylesheet\"
            type=\"text/css\"
            href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/css/fonts/icomoon/icomoon.css"), "html", null, true);
        echo "\"
    />
    <!-- link to wow js animation -->
    <link media=\"all\" rel=\"stylesheet\" href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/animate/animate.css"), "html", null, true);
        echo "\" />
    <!-- include bootstrap css -->
    <link media=\"all\" rel=\"stylesheet\" href=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/css/bootstrap.css"), "html", null, true);
        echo "\" />
    <!-- include owl css -->
    <link
            media=\"all\"
            rel=\"stylesheet\"
            href=\"";
        // line 50
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/owl-carousel/owl.carousel.css"), "html", null, true);
        echo "\"
    />
    <link
            media=\"all\"
            rel=\"stylesheet\"
            href=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/owl-carousel/owl.theme.css"), "html", null, true);
        echo "\"
    />
    <!-- include main css -->
    <link media=\"all\" rel=\"stylesheet\" href=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/css/main.css"), "html", null, true);
        echo "\" />
    <!-- link to revolution css  -->
    <link
            rel=\"stylesheet\"
            type=\"text/css\"
            href=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/revolution/css/settings.css"), "html", null, true);
        echo "\"
    />

</head>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 70
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 71
        echo "    ";
        // line 72
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/jquery/jquery-2.1.4.min.js"), "html", null, true);
        echo "\"></script>
    <!-- external scripts -->
    <script src=\"";
        // line 74
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/bootstrap/javascripts/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/jquery-placeholder/jquery.placeholder.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 76
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/match-height/jquery.matchHeight.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/wow/wow.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/stellar/jquery.stellar.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 79
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/validate/jquery.validate.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 80
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/waypoint/waypoints.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/counter-up/jquery.counterup.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/jquery-ui/jquery-ui.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 83
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/jQuery-touch-punch/jquery.ui.touch-punch.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 84
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/fancybox/jquery.fancybox.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 85
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/owl-carousel/owl.carousel.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/jcf/js/jcf.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 87
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/jcf/js/jcf.select.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/js/mailchimp.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/retina/retina.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/sticky-kit/sticky-kit.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/js/sticky-kit-init.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 92
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/vendors/bootstrap-datetimepicker-master/dist/js/bootstrap-datepicker.js"), "html", null, true);
        echo "\"></script>
    <!-- custom jquery script -->
    <script src=\"";
        // line 94
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/js/jquery.main.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 105
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header"));

        // line 106
        echo "
            <header id=\"header\" class=\"default-white-header\">
                <div class=\"container-fluid\">
                    <!-- logo -->
                    <div class=\"logo\">
                        <a href=\"index.html\">
                            <img class=\"normal\" src=\"";
        // line 112
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/img/logos/logo.png"), "html", null, true);
        echo "\" alt=\"Entrada\">
                            <img class=\"gray-logo\" src=\"";
        // line 113
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front/img/logos/logo.png"), "html", null, true);
        echo "\" alt=\"Entrada\">
                        </a>
                    </div>
                    <!-- main navigation -->
                    <nav class=\"navbar navbar-default\">
                        <div class=\"navbar-header\">
                            <button
                                    type=\"button\"
                                    class=\"navbar-toggle nav-opener\"
                                    data-toggle=\"collapse\"
                                    data-target=\"#nav\"
                            >
                                <span class=\"sr-only\">Toggle navigation</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>
                        <!-- main menu items and drop for mobile -->
                        <div class=\"collapse navbar-collapse\" id=\"nav\">
                            <!-- main navbar -->
                            <ul class=\"nav navbar-nav\">
                                <li><a href=\"#\"> HOME  </a></li>
                                <li><a href=\"#\"> Activites  </a></li>
                                <li><a href=\"";
        // line 137
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_hebergement_index");
        echo "\">  Hebegemenet  </a></li>
                                <li><a href=\"#\"> Voyage organise </a></li>
                                <li><a href=\"#\"> Vol  </a></li>
                                <li class=\"dropdown has-mega-dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"
                                    >Activities </a>
                                    <div class=\"dropdown-menu\">
                                        <div class=\"drop-wrap\">
                                            <div class=\"drop-holder\">
                                                <div class=\"row\">
                                                    <div class=\"col-sm-6 col-md-3\">
                                                        <div class=\"col\">
                                                            <div class=\"img-wrap\">
                                                                <a href=\"#\"
                                                                ><img
                                                                            src=\"img/generic/img-01.jpg\"
                                                                            height=\"228\"
                                                                            width=\"350\"
                                                                            alt=\"image description\"
                                                                    /></a>
                                                            </div>
                                                            <div class=\"des\">
                                                                <strong class=\"title\"
                                                                ><a href=\"hiking-camping.html\"
                                                                    >Hiking/Camping</a
                                                                    ></strong
                                                                >
                                                                <p>
                                                                    A good backpacker minimizes their impact on
                                                                    the environment, including staying on
                                                                    established trails, not disturbing
                                                                    vegetation, and carrying garbage out.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"col-sm-6 col-md-3\">
                                                        <div class=\"col\">
                                                            <div class=\"img-wrap\">
                                                                <a href=\"jungle-safari.html\"
                                                                ><img
                                                                            src=\"img/generic/img-02.jpg\"
                                                                            height=\"215\"
                                                                            width=\"370\"
                                                                            alt=\"image description\"
                                                                    /></a>
                                                            </div>
                                                            <div class=\"des\">
                                                                <strong class=\"title\"
                                                                ><a href=\"jungle-safari.html\"
                                                                    >Jungle Safari</a
                                                                    ></strong
                                                                >
                                                                <p>
                                                                    In the past, the trip was often a big-game
                                                                    hunt, but today, safari often refers to
                                                                    trips to observe and photograph wildlife—or
                                                                    hiking and sight-seeing as well.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"col-sm-6 col-md-3\">
                                                        <div class=\"col\">
                                                            <div class=\"img-wrap\">
                                                                <a href=\"city-tour.html\"
                                                                ><img
                                                                            src=\"img/generic/img-03.jpg\"
                                                                            height=\"215\"
                                                                            width=\"370\"
                                                                            alt=\"image description\"
                                                                    /></a>
                                                            </div>
                                                            <div class=\"des\">
                                                                <strong class=\"title\"
                                                                ><a href=\"city-tour.html\"
                                                                    >Urban City Tour</a
                                                                    ></strong
                                                                >
                                                                <p>
                                                                    The type of urban city tour considered here
                                                                    is a full, partial-day, or longer tour of a
                                                                    historical, or cultural or artistic site in
                                                                    one or more tourist destinations.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"col-sm-6 col-md-3\">
                                                        <div class=\"col\">
                                                            <div class=\"img-wrap\">
                                                                <a href=\"family-fun.html\"
                                                                ><img
                                                                            src=\"img/generic/img-04.jpg\"
                                                                            height=\"215\"
                                                                            width=\"370\"
                                                                            alt=\"image description\"
                                                                    /></a>
                                                            </div>
                                                            <div class=\"des\">
                                                                <strong class=\"title\"
                                                                ><a href=\"family-fun.html\"
                                                                    >Family Fun</a
                                                                    ></strong
                                                                >
                                                                <p>
                                                                    A community area is available on Trafalgar’s
                                                                    website offering members the opportunity to
                                                                    interact with fellow travelers by joining
                                                                    groups, contributing to forums.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>


                                <li class=\"visible-xs visible-sm\">
                                    <a href=\"\">
                                        <span class=\"icon icon-user\"></span>
                                        <span class=\"text\">Login</span>
                                    </a>
                                </li>
                                <li class=\"hidden-xs hidden-sm v-divider\">
                                    <a href=\"#\">
                                        <span class=\"icon icon-user\"></span>
                                    </a>
                                </li>
                                <li
                                        class=\"visible-xs visible-sm nav-visible dropdown last-dropdown v-divider\"
                                >
                                    <a href=\"my-cart.html\" data-toggle=\"dropdown\">
                                        <span class=\"icon icon-cart\"></span>
                                        <span class=\"text hidden-md hidden-lg\">Cart</span>
                                        <span class=\"text hidden-xs hidden-sm\"> </span>
                                    </a>
                                    <div class=\"dropdown-menu dropdown-md\">
                                        <div class=\"drop-wrap cart-wrap\">
                                            <strong class=\"title\">Shopping Cart</strong>
                                            <ul class=\"cart-list\">
                                                <li>

                                                    <div class=\"text-holder\">
                                                        <span class=\"amount\">x 2</span>
                                                        <div class=\"text-wrap\">
                                                            <strong class=\"name\"
                                                            ><a href=\"#\">Weekend in Paradise</a></strong
                                                            >
                                                            <span class=\"price\">\$199</span>
                                                        </div>
                                                    </div>
                                                </li>

                                                <li>
                                                    <div class=\"img\">
                                                    </div>

                                                </li>
                                            </ul>
                                            <div class=\"footer\">
                                                <a href=\"#\" class=\"btn btn-primary\"
                                                >View cart</a
                                                >

                                            </div>
                                        </div>
                                    </div>
                                </li>


                            </ul>
                        </div>
                    </nav>
                </div>
                <!-- search form -->
                <form class=\"search-form\" action=\"#\">
                    <fieldset>
                        <a href=\"#\" class=\"search-opener hidden-md hidden-lg\">
                            <span class=\"icon-search\"></span>
                        </a>
                        <div class=\"search-wrap\">
                            <a href=\"#\" class=\"search-opener close\">
                                <span class=\"icon-cross\"></span>
                            </a>
                            <div class=\"trip-form trip-form-v2 trip-search-main\">
                                <div class=\"trip-form-wrap\">
                                    <div class=\"holder\">
                                        <label>Departing</label>
                                        <div class=\"select-holder\">
                                            <div
                                                    id=\"datepicker\"
                                                    class=\"input-group date\"
                                                    data-date-format=\"mm-dd-yyyy\"
                                            >
                                                <input class=\"form-control\" type=\"text\" readonly />
                                                <span class=\"input-group-addon\"
                                                ><i class=\"icon-drop\"></i
                                                    ></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class=\"holder\">
                                        <label>Returning</label>
                                        <div class=\"select-holder\">
                                            <div
                                                    id=\"datepicker1\"
                                                    class=\"input-group date\"
                                                    data-date-format=\"mm-dd-yyyy\"
                                            >
                                                <input class=\"form-control\" type=\"text\" readonly />
                                                <span class=\"input-group-addon\"
                                                ><i class=\"icon-drop\"></i
                                                    ></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class=\"holder\">
                                        <label for=\"select-activity\">Select Activity</label>
                                        <div class=\"select-holder\">
                                            <select
                                                    class=\"trip-select trip-select-v2 acitvity\"
                                                    name=\"activity\"
                                                    id=\"select-activity\"
                                            >
                                                <option value=\"Holiday Type\">Holiday Type</option>
                                                <option value=\"Holiday Type\">Beach Holidays</option>
                                                <option value=\"Holiday Type\">Weekend Trips</option>
                                                <option value=\"Holiday Type\">Summer and Sun</option>
                                                <option value=\"Holiday Type\">Water Sports</option>
                                                <option value=\"Holiday Type\">Scuba Diving</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class=\"holder\">
                                        <label for=\"price-range\">Price Range</label>
                                        <div class=\"select-holder\">
                                            <select
                                                    class=\"trip-select trip-select-v2 price\"
                                                    name=\"activity\"
                                                    id=\"price-range\"
                                            >
                                                <option value=\"Price Range\">Price Range</option>
                                                <option value=\"Price Range\">\$1 - \$499</option>
                                                <option value=\"Price Range\">\$500 - \$999</option>
                                                <option value=\"Price Range\">\$1000 - \$1499</option>
                                                <option value=\"Price Range\">\$1500 - \$2999</option>
                                                <option value=\"Price Range\">\$3000+</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class=\"holder\">
                                        <button class=\"btn btn-trip btn-trip-v2\" type=\"submit\">
                                            Find Tours
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </header>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 407
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 408
        echo "



        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 414
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 415
        echo "        <!-- main footer -->
        <footer id=\"footer\">

            <div class=\"container\">
                <!-- newsletter form -->
                <form
                        action=\"https://html.waituk.com/entrada/php/subscribe.html\"
                        id=\"signup\"
                        method=\"post\"
                        class=\"newsletter-form\"
                >
                    <fieldset>
                        <div class=\"input-holder\">
                            <input
                                    type=\"email\"
                                    class=\"form-control\"
                                    placeholder=\"Email Address\"
                                    name=\"subscriber_email\"
                                    id=\"subscriber_email\"
                            />
                            <input type=\"submit\" value=\"GO\" />
                        </div>
                        <span class=\"info\" id=\"subscribe_message\"
                        >To receive news, updates and tour packages via email.</span
                        >
                    </fieldset>
                </form>
                <!-- footer links -->
                <div class=\"row footer-holder\">
                    <nav class=\"col-sm-4 col-lg-2 footer-nav active\">
                        <h3>About Entrada</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">The Company</a></li>
                            <li><a href=\"#\">Our Values</a></li>
                            <li><a href=\"#\">Responsiblity</a></li>
                            <li><a href=\"#\">Our Mission</a></li>
                            <li><a href=\"#\">Opportunity</a></li>
                            <li><a href=\"#\">Safety Concerns</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav\">
                        <h3>Destinations</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">Nepal</a></li>
                            <li><a href=\"#\">Thailand</a></li>
                            <li><a href=\"#\">Vietnam</a></li>
                            <li><a href=\"#\">Fiji Island</a></li>
                            <li><a href=\"#\">United States</a></li>
                            <li><a href=\"#\">Australia</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav\">
                        <h3>themes</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">Hiking and Camping</a></li>
                            <li><a href=\"#\">Trekking Tours</a></li>
                            <li><a href=\"#\">Jungle Safaris</a></li>
                            <li><a href=\"#\">Bungee Jumping</a></li>
                            <li><a href=\"#\">Wildlife &amp; Polar</a></li>
                            <li><a href=\"#\">Peak Climbing</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav\">
                        <h3>reservation</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">Booking Conditions</a></li>
                            <li><a href=\"#\">My Bookings</a></li>
                            <li><a href=\"#\">Refund Policy</a></li>
                            <li><a href=\"#\">Includes &amp; Excludes</a></li>
                            <li><a href=\"#\">Your Responsibilities</a></li>
                            <li><a href=\"#\">Order a Brochure</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav\">
                        <h3>ask Entrada</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">Why Entrada?</a></li>
                            <li><a href=\"#\">Ask an Expert</a></li>
                            <li><a href=\"#\">Safety Updates</a></li>
                            <li><a href=\"#\">We Help When...</a></li>
                            <li><a href=\"#\">Personal Matters</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav last\">
                        <h3>contact Entrada</h3>
                        <ul class=\"slide address-block\">
                            <li class=\"wrap-text\">
                                <span class=\"icon-tel\"></span>
                                <a href=\"tel:02072077878\">(020) 72077878</a>
                            </li>
                            <li class=\"wrap-text\">
                                <span class=\"icon-fax\"></span>
                                <a href=\"tel:02088828282\">(020) 88828282</a>
                            </li>
                            <li class=\"wrap-text\">
                                <span class=\"icon-email\"></span>
                                <a href=\"mailto:info@entrada.com\">info@entrada.com</a>
                            </li>
                            <li>
                                <span class=\"icon-home\"></span>
                                <address>707 London Road Isleworth, Middx TW7 7QD</address>
                            </li>
                        </ul>
                    </nav>
                </div>

                <!-- social wrap -->
                <ul class=\"social-wrap\">
                    <li class=\"facebook\">
                        <a href=\"#\">
                            <span class=\"icon-facebook\"></span>
                            <strong class=\"txt\">Like Us</strong>
                        </a>
                    </li>
                    <li class=\"twitter\">
                        <a href=\"#\">
                            <span class=\"icon-twitter\"></span>
                            <strong class=\"txt\">Follow On</strong>
                        </a>
                    </li>
                    <li class=\"google-plus\">
                        <a href=\"#\">
                            <span class=\"icon-google-plus\"></span>
                            <strong class=\"txt\">+1 On Google</strong>
                        </a>
                    </li>
                    <li class=\"vimeo\">
                        <a href=\"#\">
                            <span class=\"icon-vimeo\"></span>
                            <strong class=\"txt\">Share At</strong>
                        </a>
                    </li>
                    <li class=\"pin\">
                        <a href=\"#\">
                            <span class=\"icon-pin\"></span>
                            <strong class=\"txt\">Pin It</strong>
                        </a>
                    </li>
                    <li class=\"dribble\">
                        <a href=\"#\">
                            <span class=\"icon-dribble\"></span>
                            <strong class=\"txt\">Dribbble</strong>
                        </a>
                    </li>
                </ul>
            </div>
            <div class=\"footer-bottom\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-lg-6\">
                            <!-- copyright -->
                            <strong class=\"copyright\"
                            ><i class=\"fa fa-copyright\"></i> Copyright 2016 - Entrada - An
                                Adventure Theme - by <a href=\"#\">Waituk</a></strong
                            >
                        </div>

                    </div>
                </div>
            </div>

        </footer>



    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base_front.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  729 => 415,  719 => 414,  705 => 408,  695 => 407,  418 => 137,  391 => 113,  387 => 112,  379 => 106,  369 => 105,  357 => 94,  352 => 92,  348 => 91,  344 => 90,  340 => 89,  336 => 88,  332 => 87,  328 => 86,  324 => 85,  320 => 84,  316 => 83,  312 => 82,  308 => 81,  304 => 80,  300 => 79,  296 => 78,  292 => 77,  288 => 76,  284 => 75,  280 => 74,  274 => 72,  272 => 71,  262 => 70,  246 => 63,  238 => 58,  232 => 55,  224 => 50,  216 => 45,  211 => 43,  205 => 40,  196 => 34,  187 => 28,  178 => 22,  167 => 13,  165 => 12,  155 => 11,  136 => 7,  118 => 3,  99 => 581,  97 => 414,  94 => 413,  92 => 407,  87 => 404,  85 => 105,  74 => 96,  72 => 70,  69 => 69,  67 => 11,  64 => 10,  60 => 7,  56 => 5,  54 => 3,  50 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
{%block search%}
{% endblock %}
    <head>
    <meta charset=\"UTF-8\">
    <title>{% block title %} GetAWay {% endblock %}</title>
    {# Run `composer require symfony/webpack-encore-bundle`
           and uncomment the following Encore helpers to start using Symfony UX #}

    {% block stylesheets %}
    {#{{ encore_entry_link_tags('app') }}#}
    <meta charset=\"utf-8\" />
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title>Entrada</title>
    <!-- favion -->
    <link
            rel=\"icon\"
            type=\"image/png\"
            sizes=\"16x16\"
            href=\"{{ asset('front/img/favicon-16x16.png')}}\"
    />
    <!-- link to font awesome -->
    <link
            media=\"all\"
            rel=\"stylesheet\"
            href=\"{{ asset('front/vendors/font-awesome/css/font-awesome.css')}}\"
    />
    <!-- link to material icon font -->
    <link
            media=\"all\"
            rel=\"stylesheet\"
            href=\"{{ asset('front/vendors/material-design-icons/material-icons.css')}}\"
    />

    <link
            rel=\"stylesheet\"
            type=\"text/css\"
            href=\"{{ asset('front/css/fonts/icomoon/icomoon.css')}}\"
    />
    <!-- link to wow js animation -->
    <link media=\"all\" rel=\"stylesheet\" href=\"{{ asset('front/vendors/animate/animate.css')}}\" />
    <!-- include bootstrap css -->
    <link media=\"all\" rel=\"stylesheet\" href=\"{{ asset('front/css/bootstrap.css')}}\" />
    <!-- include owl css -->
    <link
            media=\"all\"
            rel=\"stylesheet\"
            href=\"{{ asset('front/vendors/owl-carousel/owl.carousel.css')}}\"
    />
    <link
            media=\"all\"
            rel=\"stylesheet\"
            href=\"{{ asset('front/vendors/owl-carousel/owl.theme.css')}}\"
    />
    <!-- include main css -->
    <link media=\"all\" rel=\"stylesheet\" href=\"{{ asset('front/css/main.css')}}\" />
    <!-- link to revolution css  -->
    <link
            rel=\"stylesheet\"
            type=\"text/css\"
            href=\"{{ asset('front/vendors/revolution/css/settings.css')}}\"
    />

</head>

{% endblock %}

{% block javascripts %}
    {#{{ encore_entry_script_tags('app') }}#}
    <script src=\"{{ asset('front/vendors/jquery/jquery-2.1.4.min.js')}}\"></script>
    <!-- external scripts -->
    <script src=\"{{ asset('front/vendors/bootstrap/javascripts/bootstrap.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/jquery-placeholder/jquery.placeholder.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/match-height/jquery.matchHeight.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/wow/wow.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/stellar/jquery.stellar.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/validate/jquery.validate.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/waypoint/waypoints.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/counter-up/jquery.counterup.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/jquery-ui/jquery-ui.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/jQuery-touch-punch/jquery.ui.touch-punch.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/fancybox/jquery.fancybox.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/owl-carousel/owl.carousel.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/jcf/js/jcf.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/jcf/js/jcf.select.js')}}\"></script>
    <script src=\"{{ asset('front/js/mailchimp.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/retina/retina.min.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/sticky-kit/sticky-kit.js')}}\"></script>
    <script src=\"{{ asset('front/js/sticky-kit-init.js')}}\"></script>
    <script src=\"{{ asset('front/vendors/bootstrap-datetimepicker-master/dist/js/bootstrap-datepicker.js')}}\"></script>
    <!-- custom jquery script -->
    <script src=\"{{ asset('front/js/jquery.main.js')}}\"></script>
{% endblock %}
</head>
<body class=\"default-page\">
<div class=\"preloader\" id=\"pageLoad\">
    <div class=\"holder\">
        <div class=\"coffee_cup\"></div>
    </div>
</div>
<div id=\"wrapper\">
    <div class=\"page-wrapper\">
        {% block header %}

            <header id=\"header\" class=\"default-white-header\">
                <div class=\"container-fluid\">
                    <!-- logo -->
                    <div class=\"logo\">
                        <a href=\"index.html\">
                            <img class=\"normal\" src=\"{{ asset('front/img/logos/logo.png') }}\" alt=\"Entrada\">
                            <img class=\"gray-logo\" src=\"{{ asset('front/img/logos/logo.png') }}\" alt=\"Entrada\">
                        </a>
                    </div>
                    <!-- main navigation -->
                    <nav class=\"navbar navbar-default\">
                        <div class=\"navbar-header\">
                            <button
                                    type=\"button\"
                                    class=\"navbar-toggle nav-opener\"
                                    data-toggle=\"collapse\"
                                    data-target=\"#nav\"
                            >
                                <span class=\"sr-only\">Toggle navigation</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>
                        <!-- main menu items and drop for mobile -->
                        <div class=\"collapse navbar-collapse\" id=\"nav\">
                            <!-- main navbar -->
                            <ul class=\"nav navbar-nav\">
                                <li><a href=\"#\"> HOME  </a></li>
                                <li><a href=\"#\"> Activites  </a></li>
                                <li><a href=\"{{ path('app_hebergement_index')}}\">  Hebegemenet  </a></li>
                                <li><a href=\"#\"> Voyage organise </a></li>
                                <li><a href=\"#\"> Vol  </a></li>
                                <li class=\"dropdown has-mega-dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"
                                    >Activities </a>
                                    <div class=\"dropdown-menu\">
                                        <div class=\"drop-wrap\">
                                            <div class=\"drop-holder\">
                                                <div class=\"row\">
                                                    <div class=\"col-sm-6 col-md-3\">
                                                        <div class=\"col\">
                                                            <div class=\"img-wrap\">
                                                                <a href=\"#\"
                                                                ><img
                                                                            src=\"img/generic/img-01.jpg\"
                                                                            height=\"228\"
                                                                            width=\"350\"
                                                                            alt=\"image description\"
                                                                    /></a>
                                                            </div>
                                                            <div class=\"des\">
                                                                <strong class=\"title\"
                                                                ><a href=\"hiking-camping.html\"
                                                                    >Hiking/Camping</a
                                                                    ></strong
                                                                >
                                                                <p>
                                                                    A good backpacker minimizes their impact on
                                                                    the environment, including staying on
                                                                    established trails, not disturbing
                                                                    vegetation, and carrying garbage out.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"col-sm-6 col-md-3\">
                                                        <div class=\"col\">
                                                            <div class=\"img-wrap\">
                                                                <a href=\"jungle-safari.html\"
                                                                ><img
                                                                            src=\"img/generic/img-02.jpg\"
                                                                            height=\"215\"
                                                                            width=\"370\"
                                                                            alt=\"image description\"
                                                                    /></a>
                                                            </div>
                                                            <div class=\"des\">
                                                                <strong class=\"title\"
                                                                ><a href=\"jungle-safari.html\"
                                                                    >Jungle Safari</a
                                                                    ></strong
                                                                >
                                                                <p>
                                                                    In the past, the trip was often a big-game
                                                                    hunt, but today, safari often refers to
                                                                    trips to observe and photograph wildlife—or
                                                                    hiking and sight-seeing as well.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"col-sm-6 col-md-3\">
                                                        <div class=\"col\">
                                                            <div class=\"img-wrap\">
                                                                <a href=\"city-tour.html\"
                                                                ><img
                                                                            src=\"img/generic/img-03.jpg\"
                                                                            height=\"215\"
                                                                            width=\"370\"
                                                                            alt=\"image description\"
                                                                    /></a>
                                                            </div>
                                                            <div class=\"des\">
                                                                <strong class=\"title\"
                                                                ><a href=\"city-tour.html\"
                                                                    >Urban City Tour</a
                                                                    ></strong
                                                                >
                                                                <p>
                                                                    The type of urban city tour considered here
                                                                    is a full, partial-day, or longer tour of a
                                                                    historical, or cultural or artistic site in
                                                                    one or more tourist destinations.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"col-sm-6 col-md-3\">
                                                        <div class=\"col\">
                                                            <div class=\"img-wrap\">
                                                                <a href=\"family-fun.html\"
                                                                ><img
                                                                            src=\"img/generic/img-04.jpg\"
                                                                            height=\"215\"
                                                                            width=\"370\"
                                                                            alt=\"image description\"
                                                                    /></a>
                                                            </div>
                                                            <div class=\"des\">
                                                                <strong class=\"title\"
                                                                ><a href=\"family-fun.html\"
                                                                    >Family Fun</a
                                                                    ></strong
                                                                >
                                                                <p>
                                                                    A community area is available on Trafalgar’s
                                                                    website offering members the opportunity to
                                                                    interact with fellow travelers by joining
                                                                    groups, contributing to forums.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>


                                <li class=\"visible-xs visible-sm\">
                                    <a href=\"\">
                                        <span class=\"icon icon-user\"></span>
                                        <span class=\"text\">Login</span>
                                    </a>
                                </li>
                                <li class=\"hidden-xs hidden-sm v-divider\">
                                    <a href=\"#\">
                                        <span class=\"icon icon-user\"></span>
                                    </a>
                                </li>
                                <li
                                        class=\"visible-xs visible-sm nav-visible dropdown last-dropdown v-divider\"
                                >
                                    <a href=\"my-cart.html\" data-toggle=\"dropdown\">
                                        <span class=\"icon icon-cart\"></span>
                                        <span class=\"text hidden-md hidden-lg\">Cart</span>
                                        <span class=\"text hidden-xs hidden-sm\"> </span>
                                    </a>
                                    <div class=\"dropdown-menu dropdown-md\">
                                        <div class=\"drop-wrap cart-wrap\">
                                            <strong class=\"title\">Shopping Cart</strong>
                                            <ul class=\"cart-list\">
                                                <li>

                                                    <div class=\"text-holder\">
                                                        <span class=\"amount\">x 2</span>
                                                        <div class=\"text-wrap\">
                                                            <strong class=\"name\"
                                                            ><a href=\"#\">Weekend in Paradise</a></strong
                                                            >
                                                            <span class=\"price\">\$199</span>
                                                        </div>
                                                    </div>
                                                </li>

                                                <li>
                                                    <div class=\"img\">
                                                    </div>

                                                </li>
                                            </ul>
                                            <div class=\"footer\">
                                                <a href=\"#\" class=\"btn btn-primary\"
                                                >View cart</a
                                                >

                                            </div>
                                        </div>
                                    </div>
                                </li>


                            </ul>
                        </div>
                    </nav>
                </div>
                <!-- search form -->
                <form class=\"search-form\" action=\"#\">
                    <fieldset>
                        <a href=\"#\" class=\"search-opener hidden-md hidden-lg\">
                            <span class=\"icon-search\"></span>
                        </a>
                        <div class=\"search-wrap\">
                            <a href=\"#\" class=\"search-opener close\">
                                <span class=\"icon-cross\"></span>
                            </a>
                            <div class=\"trip-form trip-form-v2 trip-search-main\">
                                <div class=\"trip-form-wrap\">
                                    <div class=\"holder\">
                                        <label>Departing</label>
                                        <div class=\"select-holder\">
                                            <div
                                                    id=\"datepicker\"
                                                    class=\"input-group date\"
                                                    data-date-format=\"mm-dd-yyyy\"
                                            >
                                                <input class=\"form-control\" type=\"text\" readonly />
                                                <span class=\"input-group-addon\"
                                                ><i class=\"icon-drop\"></i
                                                    ></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class=\"holder\">
                                        <label>Returning</label>
                                        <div class=\"select-holder\">
                                            <div
                                                    id=\"datepicker1\"
                                                    class=\"input-group date\"
                                                    data-date-format=\"mm-dd-yyyy\"
                                            >
                                                <input class=\"form-control\" type=\"text\" readonly />
                                                <span class=\"input-group-addon\"
                                                ><i class=\"icon-drop\"></i
                                                    ></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class=\"holder\">
                                        <label for=\"select-activity\">Select Activity</label>
                                        <div class=\"select-holder\">
                                            <select
                                                    class=\"trip-select trip-select-v2 acitvity\"
                                                    name=\"activity\"
                                                    id=\"select-activity\"
                                            >
                                                <option value=\"Holiday Type\">Holiday Type</option>
                                                <option value=\"Holiday Type\">Beach Holidays</option>
                                                <option value=\"Holiday Type\">Weekend Trips</option>
                                                <option value=\"Holiday Type\">Summer and Sun</option>
                                                <option value=\"Holiday Type\">Water Sports</option>
                                                <option value=\"Holiday Type\">Scuba Diving</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class=\"holder\">
                                        <label for=\"price-range\">Price Range</label>
                                        <div class=\"select-holder\">
                                            <select
                                                    class=\"trip-select trip-select-v2 price\"
                                                    name=\"activity\"
                                                    id=\"price-range\"
                                            >
                                                <option value=\"Price Range\">Price Range</option>
                                                <option value=\"Price Range\">\$1 - \$499</option>
                                                <option value=\"Price Range\">\$500 - \$999</option>
                                                <option value=\"Price Range\">\$1000 - \$1499</option>
                                                <option value=\"Price Range\">\$1500 - \$2999</option>
                                                <option value=\"Price Range\">\$3000+</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class=\"holder\">
                                        <button class=\"btn btn-trip btn-trip-v2\" type=\"submit\">
                                            Find Tours
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </header>
        {% endblock %}



        {% block content %}




        {% endblock %}
    </div>
    {% block footer %}
        <!-- main footer -->
        <footer id=\"footer\">

            <div class=\"container\">
                <!-- newsletter form -->
                <form
                        action=\"https://html.waituk.com/entrada/php/subscribe.html\"
                        id=\"signup\"
                        method=\"post\"
                        class=\"newsletter-form\"
                >
                    <fieldset>
                        <div class=\"input-holder\">
                            <input
                                    type=\"email\"
                                    class=\"form-control\"
                                    placeholder=\"Email Address\"
                                    name=\"subscriber_email\"
                                    id=\"subscriber_email\"
                            />
                            <input type=\"submit\" value=\"GO\" />
                        </div>
                        <span class=\"info\" id=\"subscribe_message\"
                        >To receive news, updates and tour packages via email.</span
                        >
                    </fieldset>
                </form>
                <!-- footer links -->
                <div class=\"row footer-holder\">
                    <nav class=\"col-sm-4 col-lg-2 footer-nav active\">
                        <h3>About Entrada</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">The Company</a></li>
                            <li><a href=\"#\">Our Values</a></li>
                            <li><a href=\"#\">Responsiblity</a></li>
                            <li><a href=\"#\">Our Mission</a></li>
                            <li><a href=\"#\">Opportunity</a></li>
                            <li><a href=\"#\">Safety Concerns</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav\">
                        <h3>Destinations</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">Nepal</a></li>
                            <li><a href=\"#\">Thailand</a></li>
                            <li><a href=\"#\">Vietnam</a></li>
                            <li><a href=\"#\">Fiji Island</a></li>
                            <li><a href=\"#\">United States</a></li>
                            <li><a href=\"#\">Australia</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav\">
                        <h3>themes</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">Hiking and Camping</a></li>
                            <li><a href=\"#\">Trekking Tours</a></li>
                            <li><a href=\"#\">Jungle Safaris</a></li>
                            <li><a href=\"#\">Bungee Jumping</a></li>
                            <li><a href=\"#\">Wildlife &amp; Polar</a></li>
                            <li><a href=\"#\">Peak Climbing</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav\">
                        <h3>reservation</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">Booking Conditions</a></li>
                            <li><a href=\"#\">My Bookings</a></li>
                            <li><a href=\"#\">Refund Policy</a></li>
                            <li><a href=\"#\">Includes &amp; Excludes</a></li>
                            <li><a href=\"#\">Your Responsibilities</a></li>
                            <li><a href=\"#\">Order a Brochure</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav\">
                        <h3>ask Entrada</h3>
                        <ul class=\"slide\">
                            <li><a href=\"#\">Why Entrada?</a></li>
                            <li><a href=\"#\">Ask an Expert</a></li>
                            <li><a href=\"#\">Safety Updates</a></li>
                            <li><a href=\"#\">We Help When...</a></li>
                            <li><a href=\"#\">Personal Matters</a></li>
                        </ul>
                    </nav>
                    <nav class=\"col-sm-4 col-lg-2 footer-nav last\">
                        <h3>contact Entrada</h3>
                        <ul class=\"slide address-block\">
                            <li class=\"wrap-text\">
                                <span class=\"icon-tel\"></span>
                                <a href=\"tel:02072077878\">(020) 72077878</a>
                            </li>
                            <li class=\"wrap-text\">
                                <span class=\"icon-fax\"></span>
                                <a href=\"tel:02088828282\">(020) 88828282</a>
                            </li>
                            <li class=\"wrap-text\">
                                <span class=\"icon-email\"></span>
                                <a href=\"mailto:info@entrada.com\">info@entrada.com</a>
                            </li>
                            <li>
                                <span class=\"icon-home\"></span>
                                <address>707 London Road Isleworth, Middx TW7 7QD</address>
                            </li>
                        </ul>
                    </nav>
                </div>

                <!-- social wrap -->
                <ul class=\"social-wrap\">
                    <li class=\"facebook\">
                        <a href=\"#\">
                            <span class=\"icon-facebook\"></span>
                            <strong class=\"txt\">Like Us</strong>
                        </a>
                    </li>
                    <li class=\"twitter\">
                        <a href=\"#\">
                            <span class=\"icon-twitter\"></span>
                            <strong class=\"txt\">Follow On</strong>
                        </a>
                    </li>
                    <li class=\"google-plus\">
                        <a href=\"#\">
                            <span class=\"icon-google-plus\"></span>
                            <strong class=\"txt\">+1 On Google</strong>
                        </a>
                    </li>
                    <li class=\"vimeo\">
                        <a href=\"#\">
                            <span class=\"icon-vimeo\"></span>
                            <strong class=\"txt\">Share At</strong>
                        </a>
                    </li>
                    <li class=\"pin\">
                        <a href=\"#\">
                            <span class=\"icon-pin\"></span>
                            <strong class=\"txt\">Pin It</strong>
                        </a>
                    </li>
                    <li class=\"dribble\">
                        <a href=\"#\">
                            <span class=\"icon-dribble\"></span>
                            <strong class=\"txt\">Dribbble</strong>
                        </a>
                    </li>
                </ul>
            </div>
            <div class=\"footer-bottom\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-lg-6\">
                            <!-- copyright -->
                            <strong class=\"copyright\"
                            ><i class=\"fa fa-copyright\"></i> Copyright 2016 - Entrada - An
                                Adventure Theme - by <a href=\"#\">Waituk</a></strong
                            >
                        </div>

                    </div>
                </div>
            </div>

        </footer>



    {% endblock %}
</div>
<!-- scroll to top -->
<div class=\"scroll-holder text-center\">
    <a href=\"javascript:\" id=\"scroll-to-top\"
    ><i class=\"icon-arrow-down\"></i
        ></a>
</div>

</body>
</html>", "base_front.html.twig", "C:\\Users\\Rayen's PC\\gestionhebergementall\\templates\\base_front.html.twig");
    }
}
