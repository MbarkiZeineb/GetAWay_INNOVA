<?php

namespace App\Controller;

use App\Entity\Promostion;
use App\Form\PromostionType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Knp\Component\Pager\PaginatorInterface;
/**
 * @Route("/promostion")
 */
class PromostionController extends AbstractController
{
    /**
     * @Route("/", name="app_promostion_index", methods={"GET"})
     */
    public function index(EntityManagerInterface $entityManager,PaginatorInterface $paginator,Request $request): Response
    {
        $allpromostions = $entityManager
            ->getRepository(Promostion::class)
            ->findAll();
        $promostions = $paginator->paginate(
        // Doctrine Query, not results
            $allpromostions,
            // Define the page parameter
            $request->query->getInt('page', 1),
            // Items per page
            2
        );
        return $this->render('promostion/index.html.twig', [
            'promostions' => $promostions,
        ]);
    }

    /**
     * @Route("/new", name="app_promostion_new", methods={"GET", "POST"})
     */
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $promostion = new Promostion();
        $form = $this->createForm(PromostionType::class, $promostion);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $promostion->getRefHebergement()->setPrix(($promostion->getRefHebergement()->getPrix()*(100-$promostion->getPourcentage()))/100);
            $entityManager=$this->getDoctrine()->getManager();
            $entityManager->persist($promostion);
            $entityManager->flush();

            return $this->redirectToRoute('app_promostion_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('promostion/new.html.twig', [
            'promostion' => $promostion,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{idRef}", name="app_promostion_show", methods={"GET"})
     */
    public function show(Promostion $promostion): Response
    {
        return $this->render('promostion/show.html.twig', [
            'promostion' => $promostion,
        ]);
    }

    /**
     * @Route("/{idRef}/edit", name="app_promostion_edit", methods={"GET", "POST"})
     */
    public function edit(Request $request, Promostion $promostion, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(PromostionType::class, $promostion);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $promostion->getRefHebergement()->setPrix(($promostion->getRefHebergement()->getPrix()*100)/(100-$promostion->getPourcentage()));
            $promostion->getRefHebergement()->setPrix(($promostion->getRefHebergement()->getPrix()*(100-$promostion->getPourcentage()))/100);

            $entityManager->flush();

            return $this->redirectToRoute('app_promostion_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('promostion/edit.html.twig', [
            'promostion' => $promostion,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{idRef}", name="app_promostion_delete", methods={"POST"})
     */
    public function delete(Request $request, Promostion $promostion, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete'.$promostion->getIdRef(), $request->request->get('_token'))) {
            $promostion->getRefHebergement()->setPrix(($promostion->getRefHebergement()->getPrix()*100)/(100-$promostion->getPourcentage()));

            $entityManager->remove($promostion);
            $entityManager->flush();
        }
        return $this->redirectToRoute('app_promostion_index', [], Response::HTTP_SEE_OTHER);
    }
}
